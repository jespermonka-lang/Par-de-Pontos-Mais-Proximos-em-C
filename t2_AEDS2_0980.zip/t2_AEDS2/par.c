// closest_pair.c
// Compilar: gcc closest_pair.c -O2 -Wall -Wextra -lm -o closest_pair
// Rodar:     ./closest_pair < input.txt

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
    double x, y;
    int id; // opcional: ajuda em depuração/identidade
} Point;

typedef struct {
    Point a, b;
    double dist2; // distância ao quadrado (evita sqrt durante o algoritmo)
    int valid;
} Pair;

static inline double dist2(Point p, Point q) {
    double dx = p.x - q.x;
    double dy = p.y - q.y;
    return dx*dx + dy*dy;
}

static Pair make_pair(Point a, Point b) {
    Pair r;
    r.a = a;
    r.b = b;
    r.dist2 = dist2(a, b);
    r.valid = 1;
    return r;
}

static Pair invalid_pair(void) {
    Pair r;
    r.valid = 0;
    r.dist2 = INFINITY;
    return r;
}

static Pair min_pair(Pair p1, Pair p2) {
    return (p1.dist2 <= p2.dist2) ? p1 : p2;
}

static int cmp_x(const void *pa, const void *pb) {
    const Point *a = (const Point*)pa;
    const Point *b = (const Point*)pb;
    if (a->x < b->x) return -1;
    if (a->x > b->x) return  1;
    if (a->y < b->y) return -1;
    if (a->y > b->y) return  1;
    return 0;
}

static int cmp_y(const void *pa, const void *pb) {
    const Point *a = (const Point*)pa;
    const Point *b = (const Point*)pb;
    if (a->y < b->y) return -1;
    if (a->y > b->y) return  1;
    if (a->x < b->x) return -1;
    if (a->x > b->x) return  1;
    return 0;
}

static Pair brute_force(Point *pts, int n) {
    if (n < 2) return invalid_pair();
    Pair best = make_pair(pts[0], pts[1]);
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            double d = dist2(pts[i], pts[j]);
            if (d < best.dist2) best = make_pair(pts[i], pts[j]);
        }
    }
    return best;
}

// px: pontos ordenados por x
// py: mesmos pontos ordenados por y
static Pair closest_rec(Point *px, Point *py, int n) {
    if (n <= 3) {
        return brute_force(px, n);
    }

    int mid = n / 2;
    double splitX = px[mid].x;

    // Separar py em pyl (esquerda) e pyr (direita) mantendo ordem por y
    Point *pyl = (Point*)malloc((size_t)mid * sizeof(Point));
    Point *pyr = (Point*)malloc((size_t)(n - mid) * sizeof(Point));
    if (!pyl || !pyr) {
        fprintf(stderr, "Erro: malloc falhou.\n");
        exit(1);
    }

    /* acha onde começa o bloco de x == splitX em px (que está ordenado por x) */
    int firstEq = mid;
    while (firstEq > 0 && px[firstEq - 1].x == splitX) {
        firstEq--;
    }

    /* quantos empates (x == splitX) precisam ir para a esquerda para fechar mid */
    int tiesNeeded = mid - firstEq;
    int tiesTaken = 0;

    int li = 0, ri = 0;
    for (int i = 0; i < n; i++) {
        if (py[i].x < splitX) {
            pyl[li++] = py[i];
        } else if (py[i].x > splitX) {
            pyr[ri++] = py[i];
        } else { // py[i].x == splitX
            if (tiesTaken < tiesNeeded) {
                pyl[li++] = py[i];
                tiesTaken++;
            } else {
                pyr[ri++] = py[i];
            }
    }
}

   
    Pair left  = closest_rec(px,      pyl, mid);
    Pair right = closest_rec(px + mid, pyr, n - mid);
    Pair best = min_pair(left, right);

    // Montar strip: pontos com |x - midX|^2 < best.dist2 (strip já em ordem de y pq veio de py)
    Point *strip = (Point*)malloc((size_t)n * sizeof(Point));
    if (!strip) {
        fprintf(stderr, "Erro: malloc falhou.\n");
        exit(1);
    }

    int s = 0;
    for (int i = 0; i < n; i++) {
        double dx = py[i].x - splitX;
        if (dx*dx < best.dist2) {
            strip[s++] = py[i];
        }
    }

    // No strip (ordenado por y), comparar cada ponto com os próximos enquanto dy^2 < best.dist2
    // Em 2D, isso limita a poucas comparações (clássico: até ~7).
    for (int i = 0; i < s; i++) {
        for (int j = i + 1; j < s; j++) {
            double dy = strip[j].y - strip[i].y;
            if (dy*dy >= best.dist2) break;
            double d = dist2(strip[i], strip[j]);
            if (d < best.dist2) best = make_pair(strip[i], strip[j]);
        }
    }

    free(pyl);
    free(pyr);
    free(strip);
    return best;
}

int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) {
        fprintf(stderr, "Entrada inválida. Use: n seguido de n linhas 'x y'\n");
        return 1;
    }
    if (n < 2) {
        printf("Precisa de pelo menos 2 pontos.\n");
        return 0;
    }

    Point *pts = (Point*)malloc((size_t)n * sizeof(Point));
    Point *px  = (Point*)malloc((size_t)n * sizeof(Point));
    Point *py  = (Point*)malloc((size_t)n * sizeof(Point));
    if (!pts || !px || !py) {
        fprintf(stderr, "Erro: malloc falhou.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        if (scanf("%lf %lf", &pts[i].x, &pts[i].y) != 2) {
            fprintf(stderr, "Erro lendo ponto %d.\n", i);
            return 1;
        }
        pts[i].id = i;
        px[i] = pts[i];
        py[i] = pts[i];
    }

    qsort(px, (size_t)n, sizeof(Point), cmp_x);
    qsort(py, (size_t)n, sizeof(Point), cmp_y);

    Pair ans = closest_rec(px, py, n);

    printf("Menor distancia = %.10f\n", sqrt(ans.dist2));
    printf("Ponto A: (%.10f, %.10f)\n", ans.a.x, ans.a.y);
    printf("Ponto B: (%.10f, %.10f)\n", ans.b.x, ans.b.y);

    free(pts);
    free(px);
    free(py);
    return 0;
}
